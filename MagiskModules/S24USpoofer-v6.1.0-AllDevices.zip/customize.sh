ui_print "S24 Ultra Spoofer"
ui_print "Spoof Your Device To S24 Ultra Spoofer"
ui_print "v6.1.0 - AllDevices"
ui_print "By: MRX7014"
sleep 3
ui_print "✨ Done, Enjoy, Don't forget to join MRX7014 Cloud"