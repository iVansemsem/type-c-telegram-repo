# Camera2API Enabler
This module enables __HAL3__ on supported Snapdragon devices, what results in extended Camera2 API capabilities.

## Instructions ##

* __Install Module__ via Magisk Manager/TWRP
* __Reboot__ Device
* __Use__ your favorite Camera app


## Changelog ##

##### V1.0.0 #####
* __Initial Release__


## Contact ##
<a href="https://github.com/Magisk-Modules-Repo/google-framework-magisk/issues">Commit an Issue</a>


## Donate ##
<a href="https://paypal.me/pinto165">PayPal</a>
