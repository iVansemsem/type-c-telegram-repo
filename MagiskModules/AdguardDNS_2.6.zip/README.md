Adguard DNS
==========

This module makes your device to use Adguard's DNS servers instead of the provided by the ISP:
* 176.103.130.130
* 176.103.130.131


